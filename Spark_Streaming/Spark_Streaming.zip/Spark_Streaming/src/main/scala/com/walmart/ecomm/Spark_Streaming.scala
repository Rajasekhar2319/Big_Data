package com.walmart.ecomm
import org.apache.spark.sql.functions._

import org.apache.spark.sql.types._
import org.apache.spark.sql.Row
import org.apache.spark.sql.Column
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.{ DataFrame, SparkSession }
import scala.collection.mutable.ListBuffer
import org.apache.spark.streaming._


object Spark_Streaming {

  def main(args: Array[String]): Unit = {

    val spark = SparkSession
      .builder().appName("Raj")
      .getOrCreate()

    //<--------------------------------Setting logger level to Error----------------->
    spark.sparkContext.setLogLevel("ERROR")

    val schema_main  = StructType(Array(
      StructField("batch_num",StringType,true),
      StructField("src_cntry",StringType,true),
      StructField("src_id",StringType,true),
      StructField("docnum", StringType, true),
      StructField("src_sys_id", StringType, true),
      StructField("lgcy_vndr", StringType, true),
      StructField("invce_dcmnt_crncy_amnt", StringType, true),
      StructField("lgcy_po_nmbr", StringType, true),
      StructField("dscnt_amnt", StringType, true),
      StructField("check_nmbr", StringType, true),
      StructField("paid_doc_crrncy_amnt", StringType, true),
      StructField("pymnt_dcmnt_crncy_key", StringType, true),
      StructField("payment_date", StringType, true),
      StructField("clrng_dcmnt_nmbr", StringType, true),
      StructField("src_tran_id", StringType, true),
      StructField("cntry_code", StringType, true),
      StructField("cmpny_code", StringType, true),
      StructField("sap_invce_nmbr", StringType, true),
      StructField("dcmnt_crrncy_key", StringType, true),
      StructField("rfrnc_dcmnt_nmbr", StringType, true),
      StructField("due_date", StringType, true),
      StructField("sap_cntrl_nmbr", StringType, true),
      StructField("intrcmpny_pymnt_flag", StringType, true),
      StructField("exchange_rate", StringType, true),
      StructField("pyng_cmpny_code", StringType, true),
      StructField("pymnt_mthd", StringType, true),
      StructField("eft_payee_name", StringType, true),
      StructField("raw_cre_dt", DateType, true)
    ))

    val inp_df = spark.readStream.format("orc").
      option("path","gs://e03591c9bf784351415834580ab26a0826e56598427bb184d14511a90794e7/stg_wmt_ww_fin_dl_tables.db/STG_US_FIN_AP_DSV_PYMT_SPARK_dp/*").
      schema(schema_main).
      load()

    val out_df = inp_df.writeStream.format("csv")
      .option("checkpointLocation", "gs://e03591c9bf784351415834580ab26a0826e56598427bb184d14511a90794e7/checkpoint1")
      .option("path", "gs://e03591c9bf784351415834580ab26a0826e56598427bb184d14511a90794e7/spark_output1")
      .start()


    /*val out_df = inp_df.writeStream.format("bigquery")
      .option("checkpointLocation", "gs://e03591c9bf784351415834580ab26a0826e56598427bb184d14511a90794e7/checkpoint")
      .option("project","wmt-gec-dev")
      .option("temporaryGcsBucket","e03591c9bf784351415834580ab26a0826e56598427bb184d14511a90794e7")
      .option("table", "wmt-gec-dev.WW_GEC_STAGE_TABLES.Raj_Streaming")
      .start()


      spark-submit \
    --deploy-mode cluster \
    --master yarn \
    --class com.walmart.ecomm.Spark_Streaming \
    /edge_data/code/svcfindatns/udp/jar/Spark_Streaming-3.148-SNAPSHOT.jar
*/
    out_df.awaitTermination()

  }
}
