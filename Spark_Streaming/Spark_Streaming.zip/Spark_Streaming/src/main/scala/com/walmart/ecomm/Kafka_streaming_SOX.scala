package com.walmart.ecomm
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.{col, concat, from_json, from_unixtime, from_utc_timestamp, lit, substring}
import org.apache.spark.sql.streaming.Trigger._
import org.apache.spark.sql.streaming.Trigger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.types._

object Kafka_streaming_SOX {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder
      .appName("EDDSparkStreamingPGOMS")
      .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
      .config("spark.sql.extensions", "org.apache.spark.sql.hudi.HoodieSparkSessionExtension")
      .config("spark.sql.sources.partitionOverwriteMode", "dynamic")
      .master("yarn")
      .getOrCreate()

    val kstore = "./keystore.jks"
    val tstore = "./truststore.jks"


    //var broker_list="kafka-980199677-1-1404497046.wus.kafka-sox-shared6-stg.ms-df-messaging.stg-az-westus-8.prod.us.walmart.net:9093,kafka-980199677-2-1404497049.wus.kafka-sox-shared6-stg.ms-df-messaging.stg-az -westus-8.prod.us.walmart.net:9093,kafka-980199677-3-1404497052.wus.kafka-sox-shared6-stg.ms-df-messaging.stg-az-westus-8.prod.us.walmart.net:9093,kafka-980199677-4-1404497055.wus.kafka-sox-shared6-stg.ms -df-messaging.stg-az-westus-8.prod.us.walmart.net:9093,kafka-980199677-5-1404497058.wus.kafka-sox-shared6-stg.ms-df-messaging.stg-az-westus-8.prod.us.walmart.net:9093,kafka-980199677-6-1404497061.wus.kafk a-sox-shared6-stg.ms-df-messaging.stg-az-westus-8.prod.us.walmart.net:9093"
    //var kafkaDF = spark.readStream.format("kafka").option("kafka.bootstrap.servers",broker_list).option("subscribe", "PROMO_EXTRACT_SOX_WESTUS").option("startingOffsets", "latest").option("kafka.ssl.truststore.location", tstore).option("kafka.security.protocol", "SSL").option("kafka.ssl.truststore.password", "Walmart@1234").option("kafka.ssl.keystore.location",kstore).option("kafka.ssl.keystore.password", "Walmart@1234").option("kafka.sasl.mechanism", "PLAIN").load()

    var broker_list="kafka-1301504412-1-1354806775.scus.kafka-v2-oms-sox-teflon-stg.ms-df-messaging.stg-az-southcentralus-10.prod.us.walmart.net:9093,kafka-1301504412-2-1354806778.scus.kafka-v2-oms-sox-teflon- stg.ms-df-messaging.stg-az-southcentralus-10.prod.us.walmart.net:9093,kafka-1301504412-3-1354806781.scus.kafka-v2-oms-sox-teflon-stg.ms-df-messaging.stg-az-southcentralus-10.prod.us.walmart.net:9093,kafka -1301504412-4-1354806784.scus.kafka-v2-oms-sox-teflon-stg.ms-df-messaging.stg-az-southcentralus-10.prod.us.walmart.net:9093,kafka-1301504412-5-1354806787.scus.kafka-v2-oms-sox-teflon-stg.ms-df-messaging.s tg-az-southcentralus-10.prod.us.walmart.net:9093,kafka-1301504412-6-1354806790.scus.kafka-v2-oms-sox-teflon-stg.ms-df-messaging.stg-az-southcentralus-10.prod.us.walmart.net:9093"

    var kafkaDF = spark.readStream.format("kafka").option("kafka.bootstrap.servers",broker_list).option("subscribe", "us-plutus-gis-events-stg").option("startingOffsets", "latest").option("kafka.ssl.truststore.location", tstore).option("kafka.security.protocol", "SSL").option("kafka.ssl.truststore.password", "Walmart@1234").option("kafka.ssl.keystore.location",kstore).option("kafka.ssl.keystore.password", "Walmart@1234").option("kafka.sasl.mechanism", "PLAIN").load()
    //us-plutus-gis-events-stg

    var valueDF = kafkaDF.select(col("value").cast("string").alias("value"), col("partition").alias("part"), col("offset").alias("offst"), lit("wmt_com").cast("String").as("op_cmpny_code"))

    val out_df = valueDF.writeStream.format("csv")
      .option("checkpointLocation", "gs://e03591c9bf784351415834580ab26a0826e56598427bb184d14511a90794e7/checkpoint_kafka_streaming_sox")
      .option("path", "gs://e03591c9bf784351415834580ab26a0826e56598427bb184d14511a90794e7/kafka_streaming_sox")
      .start()

    out_df.awaitTermination()
  }
}


/*
spark-submit  \
--master yarn \
--deploy-mode cluster \
--num-executors 15 \
--executor-cores 6 \
--executor-memory 4g \
--driver-memory=8g \  
--packages org.apache.spark:spark-sql-kafka-0-10_2.12:2.4.8 \
--files /edge_data/code/svcfindatns/udp/connection_yaml/truststore.jks,/edge_data/code/svcfindatns/udp/connection_yaml/keystore.jks \
--class com.walmart.ecomm.Kafka_streaming_SOX /edge_data/code/svcfindatns/udp/jar/Spark_Streaming-3.148-SNAPSHOT.jar

gcloud dataproc jobs submit spark \
--cluster='settlement-cluster' \
--region=us-east4 \
--class=com.walmart.ecomm.Kafka_streaming_SOX \
--files=/edge_data/code/svcfindatns/udp/connection_yaml/truststore.jks,/edge_data/code/svcfindatns/udp/connection_yaml/keystore.jks \
--jars=gs://spark-lib/bigquery/spark-bigquery-with-dependencies_2.12-0.22.2.jar,/edge_data/code/svcfindatns/udp/jar/Spark_Streaming-3.148-SNAPSHOT.jar


 */