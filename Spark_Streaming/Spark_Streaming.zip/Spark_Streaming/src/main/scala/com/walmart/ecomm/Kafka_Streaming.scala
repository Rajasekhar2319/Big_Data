package com.walmart.ecomm
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.{col, concat, from_json, from_unixtime, from_utc_timestamp, lit, substring}
import org.apache.spark.sql.streaming.Trigger._
import org.apache.spark.sql.streaming.Trigger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.types._

object Kafka_Streaming {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder
      .appName("EDDSparkStreamingPGOMS")
      .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
      .config("spark.sql.extensions", "org.apache.spark.sql.hudi.HoodieSparkSessionExtension")
      .config("spark.sql.sources.partitionOverwriteMode", "dynamic")
      .master("yarn")
      .getOrCreate()

    val kstore="./comms-oms-edd.kafka.client.wal-mart.com.jks"
    val tstore="./kafka.client.truststore.jks"


    ///var broker_list="kafka-498637915-4-529532371.stg-southcentralus-az.kafka-sct-teflon-stg.ms-df-messaging.stg-az-southcentralus-2.prod.us.walmart.net:9092,kafka-498637915-2-529532365.stg-southc entralus-az.kafka-sct-teflon-stg.ms-df-messaging.stg-az-southcentralus-2.prod.us.walmart.net:9092,kafka-498637915-6-529532377.stg-southcentralus-az.kafka-sct-teflon-stg.ms-df-messaging.stg-a z-southcentralus-2.prod.us.walmart.net:9092,kafka-498637915-5-529532374.stg-southcentralus-az.kafka-sct-teflon-stg.ms-df-messaging.stg-az-southcentralus-2.prod.us.walmart.net:9092,kafka-4986 37915-3-529532368.stg-southcentralus-az.kafka-sct-teflon-stg.ms-df-messaging.stg-az-southcentralus-2.prod.us.walmart.net:9092,kafka-498637915-1-529532362.stg-southcentralus-az.kafka-sct-teflon-stg.ms-df-messaging.stg-az-southcentralus-2.prod.us.walmart.net:9092"
    ///var kafkaDF = spark.readStream.format("kafka").option("kafka.bootstrap.servers",broker_list).option("subscribe", "PURCHASEORDER").option("startingOffsets", "latest").option("kafka.ssl.truststore.location", tstore).option("kafka.security.protocol", "SSL").option("kafka.ssl.truststore.password", "Commsedd@123").option("kafka.ssl.keystore.location",kstore).option("kafka.ssl.keystore.password", "Commsedd@123").option("kafka.sasl.mechanism", "PLAIN").load()

    val kafkaDF = spark.readStream.format("kafka").option("kafka.bootstrap.servers", "kafka-498637915-4-529532371.stg-southcentralus-az.kafka-sct-teflon-stg.ms-df-messaging.stg-az-southcentralus-2.prod.us.walmart.net:9092,kafka-498637915-2-529532365.stg-southc entralus-az.kafka-sct-teflon-stg.ms-df-messaging.stg-az-southcentralus-2.prod.us.walmart.net:9092,kafka-498637915-6-529532377.stg-southcentralus-az.kafka-sct-teflon-stg.ms-df-messaging.stg-a z-southcentralus-2.prod.us.walmart.net:9092,kafka-498637915-5-529532374.stg-southcentralus-az.kafka-sct-teflon-stg.ms-df-messaging.stg-az-southcentralus-2.prod.us.walmart.net:9092,kafka-4986 37915-3-529532368.stg-southcentralus-az.kafka-sct-teflon-stg.ms-df-messaging.stg-az-southcentralus-2.prod.us.walmart.net:9092,kafka-498637915-1-529532362.stg-southcentralus-az.kafka-sct-teflon-stg.ms-df-messaging.stg-az-southcentralus-2.prod.us.walmart.net:9092").option("subscribe", "PURCHASEORDER").option("startingOffsets", "earliest").load()

    var valueDF = kafkaDF.select(col("value").cast("string").alias("value"),col("partition").alias("part"),col("offset").alias("offst"),lit("wmt_com").cast("String").as("op_cmpny_code"))

    val out_df = valueDF.writeStream.format("csv")
      .option("checkpointLocation", "gs://e03591c9bf784351415834580ab26a0826e56598427bb184d14511a90794e7/checkpoint_kafka_streaming")
      .option("path", "gs://e03591c9bf784351415834580ab26a0826e56598427bb184d14511a90794e7/kafka_streaming")
      .start()

    out_df.awaitTermination()

    /*

    spark-submit  \
--master yarn \
--deploy-mode cluster \
--num-executors 15 \
--executor-cores 6 \
--executor-memory 4g \
--driver-memory=8g \
--packages org.apache.spark:spark-sql-kafka-0-10_2.12:2.4.8 \
--class com.walmart.ecomm.Kafka_Streaming /edge_data/code/svcfindatns/udp/jar/Spark_Streaming-3.148-SNAPSHOT.jar

     */

  }
}