package com.walmart.ecomm

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.{col, concat, from_json, from_unixtime, from_utc_timestamp, lit, substring}
import org.apache.spark.sql.streaming.Trigger._
import org.apache.spark.sql.streaming.Trigger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.types._
import org.apache.hudi.QuickstartUtils._

import scala.collection.JavaConversions._
import org.apache.spark.sql.SaveMode._
import org.apache.hudi.DataSourceReadOptions._
import org.apache.hudi.DataSourceWriteOptions._
import org.apache.hudi.config.HoodieWriteConfig._
import org.apache.hudi.{DataSourceWriteOptions, QuickstartUtils}
import org.apache.hudi.config.HoodieWriteConfig

object Hudi_Streaming {

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder
      .appName("CommsSparkStreaming")
      .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
      .config("spark.sql.extensions", "org.apache.spark.sql.hudi.HoodieSparkSessionExtension")
      .master("yarn")
      .getOrCreate()

    /*val kafkaDF = spark.readStream.format("kafka").option("kafka.bootstrap.servers", "kafka-498637915-1-1251069382.scus.kafka-v2-usgm-shared-stg.ms-df-messaging.stg-az-southcentralus-2.prod.us.walmart.net:9092,kafka-498637915-2-1251069385.scus.kafka-v2-usgm-shared-stg.ms-df-messaging.stg-az-southcentralus-2.prod.us.walmart.net:9092,kafka-498637915-3-1251069388.scus.kafka-v2-usgm-shared-stg.ms-df-messaging.stg-az-southcentralus-2.prod.us.walmart.net:9092,kafka-498637915-4-1251069391.scus.kafka-v2-usgm-shared-stg.ms-df-messaging.stg-az-southcentralus-2.prod.us.walmart.net:9092,kafka-498637915-5-1251069394.scus.kafka-v2-usgm-shared-stg.ms-df-messaging.stg-az-southcentralus-2.prod.us.walmart.net:9092,kafka-498637915-6-1251069397.scus.kafka-v2-usgm-shared-stg.ms-df-messaging.stg-az-southcentralus-2.prod.us.walmart.net:9092,kafka-498637915-7-1251069400.scus.kafka-v2-usgm-shared-stg.ms-df-messaging.stg-az-southcentralus-2.prod.us.walmart.net:9092,kafka-498637915-8-1251069403.scus.kafka-v2-usgm-shared-stg.ms-df-messaging.stg-az-southcentralus-2.prod.us.walmart.net:9092,kafka-498637915-9-1251069406.scus.kafka-v2-usgm-shared-stg.ms-df-messaging.stg-az-southcentralus-2.prod.us.walmart.net:9092").option("group.id","").option("subscribe", "hermes-message-copy").option("startingOffsets", "earliest").load()
    var valueDF = kafkaDF.select(col("value").cast("string").alias("value"))*/

    val schema_main  = StructType(Array(
      StructField("batch_num",StringType,true),
      StructField("src_cntry",StringType,true),
      StructField("src_id",StringType,true),
      StructField("docnum", StringType, true),
      StructField("src_sys_id", StringType, true),
      StructField("lgcy_vndr", StringType, true),
      StructField("invce_dcmnt_crncy_amnt", StringType, true),
      StructField("lgcy_po_nmbr", StringType, true),
      StructField("dscnt_amnt", StringType, true),
      StructField("check_nmbr", StringType, true),
      StructField("paid_doc_crrncy_amnt", StringType, true),
      StructField("pymnt_dcmnt_crncy_key", StringType, true),
      StructField("payment_date", StringType, true),
      StructField("clrng_dcmnt_nmbr", StringType, true),
      StructField("src_tran_id", StringType, true),
      StructField("cntry_code", StringType, true),
      StructField("cmpny_code", StringType, true),
      StructField("sap_invce_nmbr", StringType, true),
      StructField("dcmnt_crrncy_key", StringType, true),
      StructField("rfrnc_dcmnt_nmbr", StringType, true),
      StructField("due_date", StringType, true),
      StructField("sap_cntrl_nmbr", StringType, true),
      StructField("intrcmpny_pymnt_flag", StringType, true),
      StructField("exchange_rate", StringType, true),
      StructField("pyng_cmpny_code", StringType, true),
      StructField("pymnt_mthd", StringType, true),
      StructField("eft_payee_name", StringType, true),
      StructField("raw_cre_dt", DateType, true)
    ))

    val inp_df = spark.readStream.format("orc").
      option("path","gs://e03591c9bf784351415834580ab26a0826e56598427bb184d14511a90794e7/stg_wmt_ww_fin_dl_tables.db/STG_US_FIN_AP_DSV_PYMT_SPARK_dp/*").
      schema(schema_main).load()

    /*inp_df.createOrReplaceTempView("inp_df")

    val inp_df1 =  spark.sql("select lgcy_vndr,invce_dcmnt_crncy_amnt,check_nmbr,paid_doc_crrncy_amnt,cntry_code,sap_invce_nmbr,eft_payee_name,raw_cre_dt from inp_df limit 10")

    inp_df1.show()*/


    val inp_df1 = inp_df.select("lgcy_vndr","invce_dcmnt_crncy_amnt","check_nmbr","paid_doc_crrncy_amnt","cntry_code","sap_invce_nmbr","eft_payee_name","raw_cre_dt")
    val basepath="gs://e03591c9bf784351415834580ab26a0826e56598427bb184d14511a90794e7/stg_wmt_ww_fin_dl_tables.db/hudi_con_stream"

     inp_df1.writeStream.format("hudi").
      options(getQuickstartWriteConfigs).
      option(PRECOMBINE_FIELD.key(), "invce_dcmnt_crncy_amnt").
      option(RECORDKEY_FIELD.key(), "lgcy_vndr").
      option(PARTITIONPATH_FIELD.key(),  "raw_cre_dt").
      option(TBL_NAME.key(), "stg_wmt_ww_fin_dl_tables.HUDI_CON_stream").
       outputMode("append").
      option("checkpointLocation","gs://e03591c9bf784351415834580ab26a0826e56598427bb184d14511a90794e7/Hudi_checkpoint").
       option("truncate", "false").
       start(basepath)

    //inp_df1.awaitTermination()
    //query.awaitTermination()

    /*

    spark-submit --jars /edge_data/code/svcfindatns/udp/jar/hudi-spark-bundle_2.11-0.7.0.jar,/edge_data/code/svcfindatns/udp/jar/org.apache.avro_avro-1.8.2.jar,/edge_data/code/svcfindatns/udp/jar/spark-avro_2.12-2.4.0.jar,gs://spark-lib/bigquery/spark-bigquery-with-dependencies_2.12-0.22.0.jar,/edge_data/code/svcfindatns/udp/jar/hive-hcatalog-core-3.1.0.jar \
--master yarn \
--deploy-mode cluster \
--num-executors 15 \
--executor-cores 6 \
--executor-memory 4g \
--driver-memory=8g \
--packages org.apache.hudi:hudi-spark-bundle_2.12:0.9.0,org.apache.spark:spark-avro_2.12:2.4.4 \
--conf spark.serializer=org.apache.spark.serializer.KryoSerializer \
--conf spark.kryoserializer.buffer.max=512m \
--conf spark.sql.extensions=org.apache.spark.sql.hudi.HoodieSparkSessionExtension \
--conf spark.driver.extraClassPath=org.apache.avro_avro-1.8.2.jar:spark-avro_2.11-2.4.4.jar \
--conf spark.executor.extraClassPath=org.apache.avro_avro-1.8.2.jar:spark-avro_2.11-2.4.4.jar:hudi-spark-bundle_2.11-0.7.0.jar \
--class com.walmart.ecomm.Hudi_Streaming /edge_data/code/svcfindatns/udp/jar/Spark_Streaming-3.148-SNAPSHOT.jar
     */

  }
}
